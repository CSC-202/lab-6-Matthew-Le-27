class Node:
    value: any
    next: any

    def __init__(self, value, next):
        self.value = value
        self.next = next


class Queue:
    first: Node
    last: Node

    def __init__(self):
        self.first = None
        self.last = None

    def __len__(self):
        n: int = 0
        current = self.first
        while current != None:
            n += 1
            current = current.next
        return n

    def toPythonList(self):
        result: list = []
        current = self.first
        while current != None:
            result.append(current.value)
            current = current.next
        return result


def initialize() -> Queue:
    return Queue()


def isEmpty(data: Queue) -> bool:
    return data.first == None


def enqueue(data: Queue, value: int) -> Queue:
    if data.first == None:
        new_node = Node(value, None)
        data.first = new_node
    
    added_value = Queue()

    return data + enqueue(added_value, value)


def dequeue(data: Queue) -> tuple[Node, Queue]:
    if data.first == None:
        return None
    
    first_value = data[:1]

    return tuple[dequeue(first_value), data[1:]]


def peek(data: Queue) -> Node:
    if data.first == None:
        return None
    
    first_value = data[0]

    return peek(first_value)

def clear(data: Queue) -> Queue:
    data.first = None
    return data