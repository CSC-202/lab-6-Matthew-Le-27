class Node:
    value: any
    next: any

    def __init__(self, value, next):
        self.value = value
        self.next = next


class Stack:
    first: Node
    last: Node

    def __init__(self):
        self.first = None
        self.last = None

    def __len__(self):
        n: int = 0
        current = self.first
        while current != None:
            n += 1
            current = current.next
        return n

    def toPythonList(self):
        result: list = []
        current = self.first
        while current != None:
            result.append(current.value)
            current = current.next
        return result


def initialize() -> Stack:
   return Stack()


def isEmpty(data: Stack) -> bool:
    return data.first == None


def push(data: Stack, value: int) -> Stack:
    if data.first == None:
        data.first = Node(value, None)
        return data
    
    added_value = Stack()

    return data + push(added_value, value)


def pop(data: Stack) -> tuple[Node, Stack]:
    if data.first == None:
        return None
    
    removed_value = data[len(data) - 1]

    return tuple[pop(removed_value), data]


def peek(data: Stack) -> Node:
    if data.first == None:
        return None
    
    first_value = data[:1]

    return peek(first_value)


def clear(data: Stack) -> Stack:
    data.first = None
    return data
