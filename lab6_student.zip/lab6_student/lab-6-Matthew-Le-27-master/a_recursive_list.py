class Node:
    value: any
    next: any

    def __init__(self, value, next):
        self.value = value
        self.next = next


class List:
    first: Node
    last: Node

    def __init__(self):
        self.first = None
        self.last = None

    def __len__(self):
        n: int = 0
        current = self.first
        while current != None:
            n += 1
            current = current.next
        return n

    def toPythonList(self):
        result: list = []
        current = self.first
        while current != None:
            result.append(current.value)
            current = current.next
        return result


def initialize() -> List:
    return List()


def isEmpty(data: List) -> bool:
    return data.first == None


def addAtIndex(data: List, index: int, value: int) -> List:
    if index == len(data):
        new_node = Node(value, None)
        return data.append(new_node)
    
    before_index = data[:index]
    after_index = data[index:]

    return addAtIndex[before_index, index, value] + after_index


def removeAtIndex(data: List, index: int) -> tuple[Node, List]:
    if index == len(data):
        return data[:index]
    
    before_index = data[:index]
    after_index = data[index + 1:]

    return tuple(data[index], removeAtIndex(before_index, index) + after_index)


def addToFront(data: List, value: int) -> List:
    if data.first == None:
        data.first = Node(value, None)
        return data

    first_value = List()

    return addToFront(first_value, value) + data 


def addToBack(data: List, value: int) -> List:
    if data.first == None:
        data.first = Node(value, None)
        return data
    
    last_value = List()

    return data + addToBack(last_value, value)

def getElementAtIndex(data: List, index: int) -> Node:
    if index == 0:
        return data[0]
    
    else:
        return getElementAtIndex(data[1:], index - 1)


def clear(data: List) -> List:
    data.first = None
    return data

